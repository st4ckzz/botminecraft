# Configurações do Bot do Minecraft
# Edite as configurações abaixo de acordo com suas necessidades

# ====== CONFIGURAÇÕES DO SERVIDOR ======
# Endereço IP ou domínio do servidor Minecraft
# Exemplo: "localhost" para servidor local ou "meuservidor.com" para servidor online
SERVIDOR = "kamikazeMCc.aternos.me"

# Porta do servidor Minecraft
# Padrão: 25565 para servidores normais, mas alguns servidores podem usar outras portas
PORTA = 46931

# Nome que o bot usará no jogo
# Escolha um nome único para identificar seu bot
NOME_BOT = "MinecraftBot"

# Tipo de autenticação do servidor
# Use 'offline' para servidores piratas/offline
# Use 'online' para servidores originais que requerem conta Minecraft
TIPO_AUTENTICACAO = "offline"

# Versão específica do Minecraft para conexão
VERSAO_MINECRAFT = "1.8.8"

# ====== CONFIGURAÇÕES DE CONEXÃO ======
# Tempo de espera (em segundos) antes de tentar reconectar caso a conexão caia
TEMPO_RECONEXAO = 30

# Número máximo de tentativas de reconexão antes de desistir
MAX_TENTATIVAS = 3

# ====== CONFIGURAÇÕES DE SEGURANÇA ======
# Altura máxima que o bot pode cair sem considerar perigoso
# Aumentar este valor pode ser arriscado!
ALTURA_MAXIMA_QUEDA = 5

# Lista de blocos que o bot deve evitar por serem perigosos
BLOCOS_PERIGOSOS = [
    'lava',           # Lava (causa dano)
    'fire',           # Fogo (causa dano)
    'cactus',         # Cacto (causa dano)
    'magma_block'     # Bloco de Magma (causa dano)
]

# Lista de blocos que o bot considera seguros para pisar
BLOCOS_SEGUROS = [
    'stone',          # Pedra
    'dirt',           # Terra
    'grass_block',    # Grama
    'sand',           # Areia
    'gravel',         # Cascalho
    'cobblestone',    # Pedregulho
    'wooden_planks',  # Tábuas de Madeira
    'netherrack',     # Rocha do Nether
    'end_stone'       # Pedra do End
]

# ====== CONFIGURAÇÕES DE COMANDOS ======
# Prefixo usado antes dos comandos (exemplo: !vem, !parar)
# Você pode mudar para outro símbolo se preferir (exemplo: /, ., #)
PREFIXO_COMANDO = "!"

# ====== CONFIGURAÇÕES DE LOG ======
# Arquivo onde os logs serão salvos
# Útil para diagnosticar problemas
ARQUIVO_LOG = "minecraft_bot.log"

# Nível de detalhamento dos logs
# Opções: "DEBUG" (mais detalhado), "INFO" (normal), "WARNING" (só avisos), "ERROR" (só erros)
NIVEL_LOG = "INFO"

# Configurações adicionais para o bot
SKIN_URL = "https://namemc.com/skin/88e315b5d25d4d93"  # URL da skin do NameMC
AUTO_TELEPORT = True  # Ativar teleporte automático
TELEPORT_INTERVAL = 600  # Intervalo de teleporte em segundos (10 minutos)
TARGET_PLAYER = "Stackzzx"  # Jogador alvo para teleporte
PARTICLE_EFFECT = True  # Ativar efeito de partículas
TRACK_ENTITIES = True  # Ativar rastreamento de entidades
CREATIVE_MODE = True  # Manter bot no modo criativo