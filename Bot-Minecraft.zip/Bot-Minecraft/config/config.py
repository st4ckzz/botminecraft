from config.configuracoes import *

class BotConfig:
    # Minecraft server configuration
    HOST = SERVIDOR
    PORT = PORTA
    USERNAME = NOME_BOT
    AUTH_TYPE = TIPO_AUTENTICACAO
    VERSAO_MINECRAFT = VERSAO_MINECRAFT  # Adicionando versão do Minecraft

    # Connection settings
    RECONNECT_INTERVAL = TEMPO_RECONEXAO
    MAX_RETRIES = MAX_TENTATIVAS

    # Movement settings
    MOVEMENT_SPEED = 1.0
    JUMP_HEIGHT = 1.0
    MAX_PATHFINDING_DISTANCE = 100

    # Safety settings
    MAX_FALL_HEIGHT = ALTURA_MAXIMA_QUEDA
    DANGER_BLOCKS = BLOCOS_PERIGOSOS
    SAFE_BLOCKS = BLOCOS_SEGUROS

    # Command settings
    COMMAND_PREFIX = PREFIXO_COMANDO

    # Logging settings
    LOG_FILE = ARQUIVO_LOG
    LOG_LEVEL = NIVEL_LOG

    # Additional settings
    SKIN_URL = "https://namemc.com/skin/88e315b5d25d4d93"
    AUTO_TELEPORT = True
    TELEPORT_INTERVAL = 600
    TARGET_PLAYER = "Stackzzx"
    PARTICLE_EFFECT = True
    TRACK_ENTITIES = True
    CREATIVE_MODE = True